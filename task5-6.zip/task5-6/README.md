#### ДЗ №5

1. *Своя модель CRUD (create-read-update-delete)*
   
   ```node app.js```