module.exports = {
    'db': {
        'host': 'ds055885.mlab.com',
        'port': '55885',
        'name': 'geekbrains',
        'user': 'dbuser',
        'password': '123456'
    },
    'http': {
        'host': 'localhost',
        'port': 8888
    }
};