const mongoose = require('mongoose');
const crypto = require('crypto');
const Schema = mongoose.Schema;
const UserSchema = new Schema({
    login: {
        type: String,
        required: [true, 'Укажите логин']
    },
    password: {
        type: String,
        required: [
            true, 'Укажите пароль'
        ],
        set: v => v === ''
            ? v
            : crypto
                .createHash('md5')
                .update(v)
                .digest('hex')
    }
});

const User = mongoose.model('user', UserSchema);

module.exports = User;